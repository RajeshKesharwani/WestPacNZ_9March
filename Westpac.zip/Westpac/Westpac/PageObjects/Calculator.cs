﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.PageObjects;
using Westpac.PropertiesCollection;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Westpac.PageObjects
{
    class Calculator
    {
        public Calculator()
        {
            PageFactory.InitElements(WebDriverProperty.driver,this);
        }

        [FindsBy(How = How.LinkText, Using = "Click here to get started.")]
        public IWebElement Link_Clickheretogetstarted { get; set; }

        public KiwiSaver_Calculator clickLink()
        {
            WebDriverWait wait = new WebDriverWait(WebDriverProperty.driver, System.TimeSpan.FromSeconds(30.0));
            wait.Until(ExpectedConditions.ElementIsVisible(By.LinkText("Click here to get started.")));
            Link_Clickheretogetstarted.Click();
            return new KiwiSaver_Calculator();
        }
    }
}
