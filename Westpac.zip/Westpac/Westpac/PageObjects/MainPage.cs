﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.PageObjects;
using Westpac.PropertiesCollection;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using Westpac.Methods;
using System.Threading;
namespace Westpac.PageObjects
{
    class MainPage
    {
        public MainPage()
        {
            PageFactory.InitElements(WebDriverProperty.driver,this);
        }

        [FindsBy(How = How.Id, Using = "ubermenu-section-link-kiwisaver-ps")]
        public IWebElement LinkKiwiSaver { get; set; }


        [FindsBy(How = How.Id, Using = "ubermenu-item-cta-kiwisaver-calculators-ps")]
        public IWebElement LinkKiwiSaver_Calculator { get; set; }

        
        public Calculator openCalculator()
        {
            LinkKiwiSaver.MouseHover();
            WebDriverWait wait = new WebDriverWait(WebDriverProperty.driver,System.TimeSpan.FromSeconds(30.0));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("ubermenu-item-cta-kiwisaver-calculators-ps")));
            LinkKiwiSaver_Calculator.Click();
            return new Calculator();
        }
    }
}
