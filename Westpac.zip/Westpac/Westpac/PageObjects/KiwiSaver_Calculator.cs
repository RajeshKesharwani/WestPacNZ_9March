﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Support.PageObjects;
using NUnit.Framework;
using Westpac.PropertiesCollection;
using OpenQA.Selenium;
using Westpac.Methods;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using Westpac.ExcelHelper;
using System.Configuration;
namespace Westpac.PageObjects
{
    class KiwiSaver_Calculator
    {
        public KiwiSaver_Calculator()
        {
            PageFactory.InitElements(WebDriverProperty.driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//*[@id='calculator-embed']/iframe")]
        public IWebElement CalculatorFrame { get; set; }

        [FindsBy(How = How.CssSelector, Using = "i[class=icon]")]
        public IList<IWebElement> IconsList { get; set; }

        [FindsBy(How=How.XPath,Using="//*[@id='widget']/div/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div[1]/div[1]/div/div[2]/a/span")]
        public IWebElement LinkFindMyRate{get;set;}

        [FindsBy(How = How.XPath, Using = "Xpathofdetails")]
        public IWebElement DetailsText { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div[1]/div/div/input")]
        public IWebElement CurrentAge { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[2]/div/div/div/div[2]/div[1]/div[1]/div/div/div/div[1]/div")]
        public IWebElement EmploymentStatus { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[2]/div/div/div/div[2]/div[1]/div[1]/div/div/div/div[2]/ul/li[2]/div")]
        public IWebElement EmployedValue{ get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[2]/div/div/div/div[2]/div[1]/div[1]/div/div/div/div[2]/ul/li[2]/div/span")]
        public IWebElement SelfEmployedValue { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[2]/div/div/div/div[2]/div[1]/div[1]/div/div/div/div[2]/ul/li[3]/div/span")]
        public IWebElement NotEmployedValue { get; set; }
                    
        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input")]
        public IWebElement Salary { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='radio-option-066']")]
        public IWebElement EmployedMemberContribution_3 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='radio-option-069']")]
        public IWebElement EmployedMemberContribution_4 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='radio-option-06C']")]
        public IWebElement EmployedMemberContribution_8 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[5]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[1]")]
        public IWebElement PrescribedInvestorRate { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[5]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[2]/ul/div[2]/li/div/span")]
        public IWebElement PIR_17_5 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[5]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[2]/ul/div[1]/li/div/span")]
        public IWebElement PIR_28 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[5]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div/div[2]/ul/div[3]/li/div/span")]
        public IWebElement PIR_10_5 { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[7]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input")]
        public IWebElement CurrentKiwiSaverbalance { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[8]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[1]/div/input")]
        public IWebElement VoluntaryContributions { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[8]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div[2]/div/div[1]/div/span")]
        public IWebElement VoluntaryContributionsFrequency { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='radio-option-01V']")]
        public IWebElement RiskProfileLow { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='radio-option-01Y']")]
        public IWebElement RiskProfileMedium { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='radio-option-021']")]
        public IWebElement RiskProfileHigh { get; set; }
        
        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[1]/div/div[10]/div/div/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div/input")]
        public IWebElement SavingGoalAtRetirement { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[2]/button/span[2]")]
         public IWebElement ProjectionButton { get; set; }

         [FindsBy(How = How.XPath, Using = "//*[@id='widget']/div/div[1]/div/div[3]/div/div[1]/div[1]/div[1]/span[2]")]
        public IWebElement KiwiSaverBalanceOnUI { get; set; }
        

        public void SwitchToFrame()
        {
            WebDriverWait wait = new WebDriverWait(WebDriverProperty.driver, System.TimeSpan.FromSeconds(30.0));
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//*[@id='calculator-embed']/iframe")));
            WebDriverProperty.driver.SwitchTo().Frame(CalculatorFrame);
        }

        public void ClickOnInfo()
        {
            Thread.Sleep(1000);
            //WebDriverProperty.driver.Manage().Timeouts().ImplicitlyWait(System.TimeSpan.FromSeconds(10.0));
            //WebDriverWait wait = new WebDriverWait(WebDriverProperty.driver, System.TimeSpan.FromSeconds(30.0));
            //wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//*[@id='widget']/div/div[1]/div/div[1]/div/div[3]/div/div/div/div[2]/div[1]/div[1]/div/div[2]/a/span")));
            
            LinkFindMyRate.Click();
            ExcelLib.PopulateInCollection(ConfigurationSettings.AppSettings["InfoExcel_Path"]);
            for (int i = 1; i < 9;i++ )
            {
                WebDriverProperty.driver.FindElement(By.XPath(ExcelLib.ReadData(i, "XpathofInfo"))).Click();
                string Actual=WebDriverProperty.driver.FindElement(By.XPath(ExcelLib.ReadData(i, "Xpathofdetails"))).Text;
                
               Assert.AreEqual(ExcelLib.ReadData(i,"ExpectedOutput"),Actual,"Message displayed in UI is not as expected");
             }
            
        }
        public void FillKiwiSaverFormAndCompare()
        {
            ExcelLib.PopulateInCollection(ConfigurationSettings.AppSettings["Retirementcalculation_Path"]);
            for(int i=1;i<1000;i++)
            {
                string s = ExcelLib.ReadData(i, "CurrentAge");

                if (s != null)
                {
                    FillForm(ExcelLib.ReadData(i, "CurrentAge"), ExcelLib.ReadData(i, "EmploymentStatus"), ExcelLib.ReadData(i, "Salary"), ExcelLib.ReadData(i, "KiwiSaverContribution"), ExcelLib.ReadData(i, "PIR"), ExcelLib.ReadData(i, "RiskProfile"));
                    string ActualBalance = KiwiSaverBalanceOnUI.Text;
                    ActualBalance=ActualBalance.Substring(3);
                    Assert.AreEqual(ExcelLib.ReadData(i, "ExpectedKiwiSaverBalance"), ActualBalance, "Message displayed in UI is not as expected");
                    
                }
                else
                {
                    break;
                }
            }
        }
        private void FillForm(string age,string E_status,string Sal,string Kiwi_Contri,string PIR,string Risk_Profile)
        {
            WebDriverWait wait = new WebDriverWait(WebDriverProperty.driver, System.TimeSpan.FromSeconds(30.0));
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//*[@id='widget']/div/div[1]/div/div[1]/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div/div[1]/div/div[1]/div/div/input")));
            CurrentAge.EnterText(age);
          
            Thread.Sleep(1000);
            
            EmploymentStatus.Click();
            switch (E_status)
            {
                case "Employed": 
                    EmployedValue.Click();
                    break;
                case "Not-Employed":
                    NotEmployedValue.Click();
                    break;
                case "Self-Employed":
                    SelfEmployedValue.Click();
                    break;
            }
            Thread.Sleep(5000);
            Salary.EnterText(Sal);
            Thread.Sleep(1000);
            switch (Kiwi_Contri)
            {
                case "4": 
                    EmployedMemberContribution_4.Click();
                    break;
                case "3":
                    EmployedMemberContribution_3.Click();
                    break;
                case "8":
                    EmployedMemberContribution_8.Click();
                    break;
            }
            PrescribedInvestorRate.Click();
            switch (PIR)
            {
                case "17.5" :
                    PIR_17_5.Click();
                    break;
                case "28":
                    PIR_28.Click();
                    break;
                case "10.5":
                    PIR_10_5.Click();
                    break;
            }

            switch (Risk_Profile)
            {
                case "High":
                    RiskProfileHigh.Click();
                    break;
                case "Low":
                    RiskProfileLow.Click();
                    break;
                case "Medium":
                    RiskProfileMedium.Click();
                    break;
            }
            Thread.Sleep(1000);
            ProjectionButton.Click();
       }
    }
}
