﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Westpac.PropertiesCollection
{
    class PropertiesType
    {
    }
    enum PropetiesType
    {
        id,
        name,
        CssSelector,
        LinkText,
        XPath
    }
}
