﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Westpac.PropertiesCollection;
using OpenQA.Selenium.Interactions;
using Westpac.PageObjects;
using OpenQA.Selenium.Support.UI;
using System.Threading;

namespace Westpac.Methods
{
   public static class SetMethods
    {
        public static void MouseHover(this IWebElement element)
        {
            Actions actions = new Actions(WebDriverProperty.driver);
            actions.MoveToElement(element).Perform();
           
        }

        public static void cclick(this IWebElement element)
        {
             Actions actions = new Actions(WebDriverProperty.driver);
            actions.MoveToElement(element).Click().Perform();
        }

        public static void EnterText(this IWebElement element, string value)
        {

            element.SendKeys(value);
        }

        public static void SelectDropDown(this IWebElement element, string value)
        {
            new SelectElement(element).SelectByText(value);
        }

       }
}
