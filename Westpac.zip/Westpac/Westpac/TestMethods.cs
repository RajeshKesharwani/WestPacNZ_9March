﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using OpenQA.Selenium;
using Westpac.PropertiesCollection;
using System.Configuration;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Firefox;
using System.Threading;
using Westpac.PageObjects;
using Westpac.Methods;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.Extensions;
using Microsoft.Office.Interop.Excel;
using Westpac.ExcelHelper;
using System.Web;

namespace Westpac
{
    
    class TestMethods
    {

        static void Main(string[] args)
        {

        }
       [SetUp]
        public void TestInitialize()
        {
           //Initializing Chrome Driver
            WebDriverProperty.driver = new ChromeDriver();
           //Clearing the cookies
            WebDriverProperty.driver.Manage().Cookies.DeleteAllCookies();
            WebDriverProperty.driver.Navigate().GoToUrl(ConfigurationSettings.AppSettings["WestPacURL"]);
            WebDriverProperty.driver.Manage().Window.Maximize();
        }
       
        [Test]
        [Order(0)]
       public void Verify_Information_Icon_is_present_for_all_fields ()
        {
            try
            {

               MainPage MP = new MainPage();  //Creating the object of Main page
               Calculator SP = MP.openCalculator();  //After clicking on KiwiSavers calculator intantiating the object of Calculator Page                           
               KiwiSaver_Calculator KC = SP.clickLink();  // After Clicking on Click Here to get started intantiating the object of KiwiSaver_Calculator Page
               KC.SwitchToFrame(); //Switching to the frame inside
               KC.ClickOnInfo(); //Calling method to click on Information link
            }
            catch (Exception exception)
            {
                Assert.Fail(exception.Message + exception.StackTrace);
                
            }

        }

        [Test]
        [Order(1)]
        public void Verify_KiwiSaver_Estimated_Balance()
        {
            try
            {

                MainPage MP = new MainPage(); //Creating the object of Main page
                Calculator SP = MP.openCalculator(); //After clicking on KiwiSavers calculator intantiating the object of Calculator Page                           
                KiwiSaver_Calculator KC = SP.clickLink(); // Afte Clicking on Click Here to get started intantiating the object of KiwiSaver_Calculator Page
                KC.SwitchToFrame(); //Switching to the frame inside
                KC.FillKiwiSaverFormAndCompare(); //Calling function to fill the data on Calculator page
             }
                                           
            catch(Exception exception)
            {
                Assert.Fail(exception.Message + exception.StackTrace);
                
            }
        }

        [TearDown]
        public void CleanUp()
        {
            WebDriverProperty.driver.Quit();
        }
    }
}
